# KIS-dashboard COPD

Prototype voor een KIS-dashboard binnen COPD-ketenzorg.

## Starten

```bash
npm install
npm run dev
```

## Demo-logins

- huisarts / demo123
- longzorg / demo123
- fysiotherapie / demo123
- dietiek / demo123
- psychologie / demo123
