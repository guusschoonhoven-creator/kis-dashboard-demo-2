import React, { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  History,
  Info,
  MessageSquare,
  CheckSquare,
  ShieldCheck,
  LogOut,
  Lock,
  AlertTriangle,
  Lightbulb,
} from "lucide-react";

const PATIENT = {
  name: "de Wit, A. (fictief)",
  diagnosis: "COPD GOLD III",
  allergy: "Penicilline",
  fev1: "42%",
  spo2: "91%",
};

const USERS = {
  huisarts: {
    password: "demo123",
    label: "Huisarts",
    role: "Brede inzage in meerdere disciplines",
    disciplineId: "huisarts",
    allowedTabs: ["overzicht", "gordon", "geschiedenis", "communicatie", "taken", "ideeen", "privacy"],
    canSwitchDiscipline: true,
  },
  longzorg: {
    password: "demo123",
    label: "Longzorg",
    role: "Alleen disciplinegebonden informatie",
    disciplineId: "longzorg",
    allowedTabs: ["overzicht", "geschiedenis", "communicatie"],
    canSwitchDiscipline: false,
  },
  fysiotherapie: {
    password: "demo123",
    label: "Fysiotherapie",
    role: "Alleen disciplinegebonden informatie",
    disciplineId: "fysiotherapie",
    allowedTabs: ["overzicht", "geschiedenis", "communicatie"],
    canSwitchDiscipline: false,
  },
  dietiek: {
    password: "demo123",
    label: "Diëtiek",
    role: "Alleen disciplinegebonden informatie",
    disciplineId: "dietetiek",
    allowedTabs: ["overzicht", "geschiedenis", "communicatie"],
    canSwitchDiscipline: false,
  },
  psychologie: {
    password: "demo123",
    label: "Psychologie",
    role: "Alleen disciplinegebonden informatie",
    disciplineId: "psychologie",
    allowedTabs: ["overzicht", "geschiedenis", "communicatie"],
    canSwitchDiscipline: false,
  },
};

const DISCIPLINES = [
  {
    id: "huisarts",
    label: "Huisarts",
    role: "Signalering, verwijzing en follow-up",
    overview: [
      ["Consulten", "8x", "Afgelopen jaar"],
      ["Ketenzorg", "Actief", "COPD"],
      ["Vaccinatie", "2024", "Up-to-date"],
      ["Bloeddruk", "138/84", "Acceptabel"],
    ],
    history: [
      ["Telefonisch contact — toename klachten", "10 mei 2025"],
      ["Controle na ziekenhuisopname exacerbatie", "20 mrt 2025"],
      ["Jaarcontrole ketenzorg COPD", "15 jan 2025"],
      ["Doorverwijzing longarts vastgelegd", "8 sep 2024"],
    ],
  },
  {
    id: "longzorg",
    label: "Longzorg",
    role: "Diagnose, stadiëring en specialistische opvolging",
    overview: [
      ["FEV1", "42%", "GOLD III"],
      ["SpO₂", "91%", "Onder streefwaarde"],
      ["Exacerbaties", "3", "Afgelopen jaar"],
      ["Risico", "Hoog", "Alert actief"],
    ],
    history: [
      ["Exacerbatie behandeld — ziekenhuisopname 5 dagen", "14 mrt 2025"],
      ["Spirometrie: FEV1 42%, FVC 61%", "12 feb 2025"],
      ["Start longrevalidatie-programma", "5 jan 2025"],
      ["Diagnose COPD GOLD III gesteld", "8 sep 2024"],
    ],
  },
  {
    id: "fysiotherapie",
    label: "Fysiotherapie",
    role: "Longrevalidatie en belastbaarheid",
    overview: [
      ["6MWT", "210 m", "Lage belastbaarheid"],
      ["MRC", "3/5", "Dyspnoe"],
      ["Sessies", "2x/wk", "Actief"],
      ["Status", "Lopend", "Revalidatie"],
    ],
    history: [
      ["Voortgang longrevalidatie: 6MWT 210m", "12 mei 2025"],
      ["Herstart programma na exacerbatie", "21 mrt 2025"],
      ["Baseline 6MWT: 250m", "1 feb 2025"],
      ["Start longrevalidatie-programma", "5 jan 2025"],
    ],
  },
  {
    id: "dietetiek",
    label: "Diëtiek",
    role: "Voedingstoestand en gewichtsverlies",
    overview: [
      ["Gewicht", "71 kg", "↓ 4 kg / 6 weken"],
      ["BMI", "21.4", "Grensgebied"],
      ["FFMI", "16.2", "Spiermassa laag"],
      ["Intake", "Open", "Inplannen"],
    ],
    history: [
      ["Verwijzing diëtetiek aangevraagd", "12 mei 2025"],
      ["Gewicht 71 kg — daling zichtbaar", "12 mei 2025"],
      ["Gewicht 73 kg — lichte daling", "1 feb 2025"],
      ["Baseline gewicht: 75 kg", "1 dec 2024"],
    ],
  },
  {
    id: "psychologie",
    label: "Psychologie",
    role: "Coping, angst en psychosociale ondersteuning",
    overview: [
      ["Coping", "Matig", "Begeleiding nodig"],
      ["Angst", "Aanwezig", "Bij dyspnoe"],
      ["Steun", "Ja", "Mantelzorger"],
      ["Status", "Advies", "Nog niet actief"],
    ],
    history: [
      ["Angst voor benauwdheid besproken", "12 mei 2025"],
      ["Psychologische begeleiding aanbevolen", "20 mrt 2025"],
      ["Stress & coping kwetsbaar gescoord", "1 mrt 2025"],
      ["Mantelzorger betrokken bij begeleiding", "15 jan 2025"],
    ],
  },
];

const GORDON = [
  ["Gezondheidsbeleving", 3, "Hoog risico", "Rookhistorie en therapietrouw vragen aandacht."],
  ["Voeding & metabolisme", 2, "Hoog risico", "Gewichtsverlies van 4 kg in 6 weken."],
  ["Uitscheiding", 7, "Stabiel", "Geen bijzonderheden."],
  ["Activiteit & beweging", 3, "Aandacht", "MRC dyspnoe graad 3 en beperkte loopafstand."],
  ["Slaap & rust", 4, "Aandacht", "Nachtelijke benauwdheid/hypoxemie gemeld."],
  ["Cognitie & waarneming", 8, "Stabiel", "Geen cognitieve beperkingen bekend."],
  ["Zelfbeleving", 4, "Aandacht", "Angst voor benauwdheid aanwezig."],
  ["Rollen & relaties", 6, "Stabiel", "Mantelzorger aanwezig."],
  ["Seksualiteit & reproductie", 7, "Stabiel", "Geen actuele hulpvraag."],
  ["Stress & coping", 3, "Hoog risico", "Coping vraagt begeleiding."],
  ["Waarden & levensovertuiging", 6, "Stabiel", "Geen bezwaren tegen behandeling."],
];

const TABS = [
  ["overzicht", "Overzicht", LayoutDashboard],
  ["gordon", "Gordon-domeinen", Info],
  ["geschiedenis", "Geschiedenis", History],
  ["communicatie", "Communicatie", MessageSquare],
  ["taken", "Taken", CheckSquare],
  ["ideeen", "Ideeënbox", Lightbulb],
  ["privacy", "Privacy/AVG", ShieldCheck],
];

function LoginScreen({ onLogin }) {
  const [username, setUsername] = useState("huisarts");
  const [password, setPassword] = useState("demo123");
  const [error, setError] = useState("");

  function submit(e) {
    e.preventDefault();
    const user = USERS[username.toLowerCase()];
    if (!user || user.password !== password) {
      setError("Ongeldige gebruikersnaam of wachtwoord.");
      return;
    }
    onLogin({ username: username.toLowerCase(), ...user });
  }

  return (
    <div className="min-h-screen bg-[#f7f7f4] flex items-center justify-center p-6 text-slate-900">
      <motion.form
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={submit}
        className="w-full max-w-xl rounded-3xl border border-slate-200 bg-white p-8 shadow-sm"
      >
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-100 text-blue-800">
            <Lock size={24} />
          </div>
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">KIS-Dashboard COPD</h1>
            <p className="text-slate-500">Demo-omgeving met rolgebaseerde toegang</p>
          </div>
        </div>

        <div className="mb-5 rounded-2xl border border-blue-100 bg-blue-50 p-4 text-sm text-blue-900">
          <strong>Demo-logins:</strong> huisarts/demo123, longzorg/demo123, fysiotherapie/demo123, dietiek/demo123, psychologie/demo123
        </div>

        <label className="mb-2 block text-sm font-medium text-slate-700">Gebruikersnaam</label>
        <input value={username} onChange={(e) => setUsername(e.target.value)} className="mb-4 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-500" />

        <label className="mb-2 block text-sm font-medium text-slate-700">Wachtwoord</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" className="mb-4 w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-blue-500" />

        {error && <div className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</div>}

        <button className="w-full rounded-xl bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">Inloggen</button>
      </motion.form>
    </div>
  );
}

function Overview({ discipline }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-5 text-2xl font-medium text-slate-900">Actueel overzicht — {discipline.label.toLowerCase()}</h2>
      <div className="grid gap-4 md:grid-cols-4">
        {discipline.overview.map(([label, value, note]) => (
          <div key={label} className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <div className="text-sm text-slate-500">{label}</div>
            <div className="mt-1 text-2xl font-semibold text-slate-900">{value}</div>
            <div className="mt-1 text-sm text-slate-500">{note}</div>
          </div>
        ))}
      </div>
      <div className="mt-5 rounded-2xl border border-red-100 bg-red-50 p-4 text-sm text-red-900">
        <strong>Let op:</strong> SpO₂ 91%, gewichtsverlies en meerdere exacerbaties vragen om opvolging binnen de keten.
      </div>
    </motion.div>
  );
}

function GordonView() {
  const [open, setOpen] = useState("Gezondheidsbeleving");

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-2 text-2xl font-medium text-slate-900">Gordon-domeinen</h2>
      <p className="mb-5 text-slate-500">Klik op een leefregel voor toelichting.</p>

      <div className="space-y-3">
        {GORDON.map(([name, value, status, note]) => {
          const bar = value <= 3 ? "bg-red-500" : value === 4 ? "bg-amber-500" : "bg-emerald-500";
          const chip = value <= 3 ? "bg-red-100 text-red-800" : value === 4 ? "bg-amber-100 text-amber-800" : "bg-emerald-100 text-emerald-800";
          return (
            <button key={name} onClick={() => setOpen(open === name ? "" : name)} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-left hover:bg-white">
              <div className="flex items-center gap-4">
                <div className="w-60 text-base font-medium text-slate-800">{name}</div>
                <div className="h-3 flex-1 overflow-hidden rounded-full bg-slate-200">
                  <div className={`h-full rounded-full ${bar}`} style={{ width: `${value * 10}%` }} />
                </div>
                <div className="w-10 text-right font-semibold text-slate-700">{value}</div>
                <span className={`rounded-full px-4 py-1.5 text-sm ${chip}`}>{status}</span>
              </div>
              {open === name && <div className="mt-3 rounded-xl bg-white p-3 text-sm text-slate-600">{note}</div>}
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}

function HistoryView({ discipline }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white px-8 py-7">
      <h2 className="mb-7 text-2xl font-medium text-slate-900">Medische geschiedenis — {discipline.label.toLowerCase()}</h2>
      <div className="divide-y divide-slate-200">
        {discipline.history.map(([event, date]) => (
          <div key={event} className="py-4 first:pt-0">
            <div className="text-xl text-slate-900">{event}</div>
            <div className="text-lg text-slate-500">{date}</div>
          </div>
        ))}
      </div>
      <div className="mt-5 text-sm text-slate-700">
        Toegang beperkt tot discipline: <strong>{discipline.label}</strong> · conform AVG/NEN 7510.
      </div>
    </motion.div>
  );
}

function CommunicationView({ discipline, messages, setMessages }) {
  const [to, setTo] = useState("Longzorg");
  const [subject, setSubject] = useState("Vraag over COPD-zorgplan");
  const [message, setMessage] = useState("");

  function sendMessage() {
    if (!message.trim()) return;
    setMessages([{ id: Date.now(), from: discipline.label, to, subject, message, date: new Date().toLocaleDateString("nl-NL") }, ...messages]);
    setMessage("");
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-5 text-2xl font-medium">Communicatie tussen disciplines</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <select value={to} onChange={(e) => setTo(e.target.value)} className="rounded-xl border border-slate-300 px-4 py-3">
          {DISCIPLINES.map((d) => <option key={d.id}>{d.label}</option>)}
        </select>
        <input value={subject} onChange={(e) => setSubject(e.target.value)} className="md:col-span-2 rounded-xl border border-slate-300 px-4 py-3" />
        <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Typ hier een bericht of overdracht..." className="md:col-span-3 min-h-[120px] rounded-xl border border-slate-300 px-4 py-3" />
      </div>
      <button onClick={sendMessage} className="mt-4 rounded-xl bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">Bericht versturen</button>
      <div className="mt-6 space-y-3">
        {messages.map((m) => (
          <div key={m.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="font-semibold">{m.subject}</div>
            <div className="text-sm text-slate-500">Van {m.from} naar {m.to} · {m.date}</div>
            <div className="mt-2 text-slate-700">{m.message}</div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function TasksView({ tasks, setTasks }) {
  const [task, setTask] = useState("");
  const [owner, setOwner] = useState("Longzorg");
  const [priority, setPriority] = useState("Hoog");

  function addTask() {
    if (!task.trim()) return;
    setTasks([{ id: Date.now(), task, owner, priority, done: false }, ...tasks]);
    setTask("");
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-5 text-2xl font-medium">Taken toewijzen</h2>
      <div className="grid gap-4 md:grid-cols-4">
        <input value={task} onChange={(e) => setTask(e.target.value)} placeholder="Nieuwe taak..." className="md:col-span-2 rounded-xl border border-slate-300 px-4 py-3" />
        <select value={owner} onChange={(e) => setOwner(e.target.value)} className="rounded-xl border border-slate-300 px-4 py-3">
          {DISCIPLINES.map((d) => <option key={d.id}>{d.label}</option>)}
        </select>
        <select value={priority} onChange={(e) => setPriority(e.target.value)} className="rounded-xl border border-slate-300 px-4 py-3">
          <option>Urgent</option>
          <option>Hoog</option>
          <option>Middel</option>
          <option>Laag</option>
        </select>
      </div>
      <button onClick={addTask} className="mt-4 rounded-xl bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">Taak toevoegen</button>

      <div className="mt-6 space-y-3">
        {tasks.map((t) => (
          <div key={t.id} className="flex items-center justify-between rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div>
              <div className={`font-semibold ${t.done ? "line-through text-slate-400" : "text-slate-900"}`}>{t.task}</div>
              <div className="text-sm text-slate-500">Eigenaar: {t.owner} · Prioriteit: {t.priority}</div>
            </div>
            <button onClick={() => setTasks(tasks.map((x) => x.id === t.id ? { ...x, done: !x.done } : x))} className="rounded-xl border border-slate-300 px-4 py-2 text-sm hover:bg-white">
              {t.done ? "Heropenen" : "Afronden"}
            </button>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function IdeasView({ ideas, setIdeas }) {
  const [text, setText] = useState("");
  const [category, setCategory] = useState("Gebruiksvriendelijkheid");

  function addIdea() {
    if (!text.trim()) return;
    setIdeas([{ id: Date.now(), text, category, status: "Open" }, ...ideas]);
    setText("");
  }

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-5 text-2xl font-medium">Ideeënbox</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Verbeteridee..." className="md:col-span-2 rounded-xl border border-slate-300 px-4 py-3" />
        <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-xl border border-slate-300 px-4 py-3">
          <option>Gebruiksvriendelijkheid</option>
          <option>Taakverdeling</option>
          <option>Privacy/veiligheid</option>
          <option>Werkdruk</option>
        </select>
      </div>
      <button onClick={addIdea} className="mt-4 rounded-xl bg-blue-700 px-5 py-3 font-semibold text-white hover:bg-blue-800">Idee toevoegen</button>
      <div className="mt-6 space-y-3">
        {ideas.map((i) => (
          <div key={i.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="font-semibold">{i.text}</div>
            <div className="text-sm text-slate-500">Categorie: {i.category} · Status: {i.status}</div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function PrivacyView() {
  const items = [
    ["AVG", "Medische persoonsgegevens mogen alleen worden ingezien door bevoegde zorgverleners."],
    ["DPIA", "Voor ingebruikname moet vooraf worden gekeken naar privacyrisico’s."],
    ["NEN 7510", "Informatiebeveiliging in de zorg: veilige toegang, autorisatie en beheer."],
    ["NEN 7512", "Veilige gegevensuitwisseling tussen zorgpartijen en systemen."],
    ["NEN 7513", "Logging: zichtbaar maken wie gegevens heeft bekeken of aangepast."],
    ["HL7/FHIR", "Standaarden voor digitale gegevensuitwisseling tussen HIS, KIS en andere systemen."],
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="rounded-2xl border border-slate-200 bg-white p-7">
      <h2 className="mb-5 text-2xl font-medium">Privacy, wetgeving en standaarden</h2>
      <div className="space-y-3">
        {items.map(([title, text]) => (
          <div key={title} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
            <div className="font-semibold text-slate-900">{title}</div>
            <div className="text-slate-600">{text}</div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function Dashboard({ user, onLogout }) {
  const [disciplineId, setDisciplineId] = useState(user.disciplineId);
  const [tab, setTab] = useState(user.allowedTabs[0]);
  const [messages, setMessages] = useState([
    {
      id: 1,
      from: "Huisarts",
      to: "Longzorg",
      subject: "Verwijzing bij verslechtering",
      message: "Patiënt meldt toename dyspnoe en vermoeidheid. Graag beoordeling longzorg.",
      date: "12 mei 2025",
    },
  ]);
  const [tasks, setTasks] = useState([
    { id: 1, task: "Zuurstoftherapie herzien bij SpO₂ 91%", owner: "Longzorg", priority: "Urgent", done: false },
    { id: 2, task: "Diëtetiek-intake plannen vanwege gewichtsverlies", owner: "Diëtiek", priority: "Hoog", done: false },
  ]);
  const [ideas, setIdeas] = useState([
    { id: 1, text: "Maak de belangrijkste COPD-alerts direct zichtbaar bovenaan het dashboard.", category: "Gebruiksvriendelijkheid", status: "In behandeling" },
  ]);

  const discipline = useMemo(() => DISCIPLINES.find((d) => d.id === disciplineId), [disciplineId]);
  const visibleTabs = TABS.filter(([id]) => user.allowedTabs.includes(id));

  function changeDiscipline(id) {
    if (!user.canSwitchDiscipline) return;
    setDisciplineId(id);
  }

  return (
    <div className="min-h-screen bg-[#f7f7f4] font-sans text-slate-900">
      <header className="flex min-h-[96px] items-center border-b border-slate-200 bg-white px-8">
        <div>
          <div className="text-3xl font-medium tracking-tight">
            KIS-Dashboard <span className="text-blue-700">COPD-Ketenzorg</span>
          </div>
          <div className="text-slate-500">Ingelogd als {user.label} · {user.role}</div>
        </div>

        <div className="mx-auto rounded-full bg-blue-100 px-7 py-2 text-lg font-medium text-blue-900">Demo-omgeving</div>

        <button onClick={onLogout} className="flex items-center gap-2 rounded-xl border border-slate-300 px-4 py-2 hover:bg-slate-50">
          <LogOut size={18} /> Uitloggen
        </button>
      </header>

      <div className="flex">
        <aside className="min-h-[calc(100vh-96px)] w-[340px] shrink-0 bg-black px-5 py-8 text-white">
          <div className="mb-4 px-3 text-lg font-bold uppercase tracking-wide text-white/70">Discipline</div>
          <div className="space-y-2">
            {DISCIPLINES.map((d) => (
              <button
                key={d.id}
                onClick={() => changeDiscipline(d.id)}
                disabled={!user.canSwitchDiscipline && d.id !== user.disciplineId}
                className={`w-full rounded-xl border px-5 py-4 text-left text-base font-semibold transition ${
                  d.id === disciplineId
                    ? "border-slate-400 bg-white/10 text-white"
                    : "border-white/10 text-white/60 hover:border-white/30 hover:text-white disabled:opacity-25"
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </aside>

        <main className="flex-1 p-8">
          <section className="mb-6 grid gap-4 rounded-3xl border border-slate-200 bg-white p-6 md:grid-cols-5">
            <div><div className="text-sm text-slate-500">Patiënt</div><div className="text-xl font-semibold">{PATIENT.name}</div></div>
            <div><div className="text-sm text-slate-500">Diagnose</div><div className="text-xl font-semibold">{PATIENT.diagnosis}</div></div>
            <div><div className="text-sm text-slate-500">FEV1</div><div className="text-xl font-semibold">{PATIENT.fev1}</div></div>
            <div><div className="text-sm text-slate-500">SpO₂</div><div className="text-xl font-semibold text-red-700">{PATIENT.spo2}</div></div>
            <div><div className="text-sm text-slate-500">Allergie</div><div className="text-xl font-semibold">{PATIENT.allergy}</div></div>
          </section>

          <section className="mb-6 rounded-3xl border border-amber-200 bg-amber-50 p-5 text-amber-900">
            <div className="flex items-center gap-3 font-semibold">
              <AlertTriangle size={20} /> Sluipende trend-alert
            </div>
            <div className="mt-1 text-sm">Gewichtsverlies, lage saturatie en verminderde belastbaarheid zichtbaar. Koppel vervolgactie aan juiste discipline.</div>
          </section>

          <nav className="mb-6 flex flex-wrap gap-3">
            {visibleTabs.map(([id, label, Icon]) => (
              <button
                key={id}
                onClick={() => setTab(id)}
                className={`flex items-center gap-2 rounded-xl border px-5 py-3 font-semibold ${
                  tab === id ? "border-blue-700 bg-blue-700 text-white" : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
                }`}
              >
                <Icon size={18} /> {label}
              </button>
            ))}
          </nav>

          {tab === "overzicht" && <Overview discipline={discipline} />}
          {tab === "gordon" && <GordonView />}
          {tab === "geschiedenis" && <HistoryView discipline={discipline} />}
          {tab === "communicatie" && <CommunicationView discipline={discipline} messages={messages} setMessages={setMessages} />}
          {tab === "taken" && <TasksView tasks={tasks} setTasks={setTasks} />}
          {tab === "ideeen" && <IdeasView ideas={ideas} setIdeas={setIdeas} />}
          {tab === "privacy" && <PrivacyView />}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  if (!user) return <LoginScreen onLogin={setUser} />;
  return <Dashboard user={user} onLogout={() => setUser(null)} />;
}
